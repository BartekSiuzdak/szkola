﻿
namespace lekcja
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.rejestracja_label = new System.Windows.Forms.Label();
            this.nazwisko = new System.Windows.Forms.TextBox();
            this.imie = new System.Windows.Forms.TextBox();
            this.data_urodzenia = new System.Windows.Forms.DateTimePicker();
            this.miejsce_urodzenia = new System.Windows.Forms.TextBox();
            this.nazwisko_label = new System.Windows.Forms.Label();
            this.imie_label = new System.Windows.Forms.Label();
            this.data_urodzenia_label = new System.Windows.Forms.Label();
            this.miejsce_urodzenia_label = new System.Windows.Forms.Label();
            this.kod_mask = new System.Windows.Forms.MaskedTextBox();
            this.adres = new System.Windows.Forms.TextBox();
            this.adres_label = new System.Windows.Forms.Label();
            this.kod_pocztowy_label = new System.Windows.Forms.Label();
            this.numer_telefonu_mask = new System.Windows.Forms.MaskedTextBox();
            this.numer_telefonu_label = new System.Windows.Forms.Label();
            this.submit = new System.Windows.Forms.Button();
            this.results = new System.Windows.Forms.Label();
            this.image = new System.Windows.Forms.TextBox();
            this.zdjecie_label = new System.Windows.Forms.Label();
            this.zdjecie = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.zdjecie)).BeginInit();
            this.SuspendLayout();
            // 
            // rejestracja_label
            // 
            this.rejestracja_label.Font = new System.Drawing.Font("Arial Narrow", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rejestracja_label.Location = new System.Drawing.Point(168, 9);
            this.rejestracja_label.Name = "rejestracja_label";
            this.rejestracja_label.Size = new System.Drawing.Size(271, 46);
            this.rejestracja_label.TabIndex = 0;
            this.rejestracja_label.Text = "REJESTRACJA";
            this.rejestracja_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // nazwisko
            // 
            this.nazwisko.Location = new System.Drawing.Point(211, 82);
            this.nazwisko.Name = "nazwisko";
            this.nazwisko.Size = new System.Drawing.Size(160, 20);
            this.nazwisko.TabIndex = 1;
            this.nazwisko.Text = "wypełnij pole";
            this.nazwisko.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // imie
            // 
            this.imie.Location = new System.Drawing.Point(211, 135);
            this.imie.Name = "imie";
            this.imie.Size = new System.Drawing.Size(160, 20);
            this.imie.TabIndex = 2;
            this.imie.Text = "wypełnij pole";
            this.imie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // data_urodzenia
            // 
            this.data_urodzenia.Location = new System.Drawing.Point(211, 193);
            this.data_urodzenia.Name = "data_urodzenia";
            this.data_urodzenia.Size = new System.Drawing.Size(160, 20);
            this.data_urodzenia.TabIndex = 4;
            // 
            // miejsce_urodzenia
            // 
            this.miejsce_urodzenia.Location = new System.Drawing.Point(211, 249);
            this.miejsce_urodzenia.Name = "miejsce_urodzenia";
            this.miejsce_urodzenia.Size = new System.Drawing.Size(160, 20);
            this.miejsce_urodzenia.TabIndex = 5;
            this.miejsce_urodzenia.Text = "wypełnij pole";
            this.miejsce_urodzenia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nazwisko_label
            // 
            this.nazwisko_label.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nazwisko_label.Location = new System.Drawing.Point(183, 55);
            this.nazwisko_label.Name = "nazwisko_label";
            this.nazwisko_label.Size = new System.Drawing.Size(218, 24);
            this.nazwisko_label.TabIndex = 8;
            this.nazwisko_label.Text = "nazwisko";
            this.nazwisko_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // imie_label
            // 
            this.imie_label.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.imie_label.Location = new System.Drawing.Point(183, 108);
            this.imie_label.Name = "imie_label";
            this.imie_label.Size = new System.Drawing.Size(218, 24);
            this.imie_label.TabIndex = 9;
            this.imie_label.Text = "imie";
            this.imie_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // data_urodzenia_label
            // 
            this.data_urodzenia_label.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.data_urodzenia_label.Location = new System.Drawing.Point(183, 166);
            this.data_urodzenia_label.Name = "data_urodzenia_label";
            this.data_urodzenia_label.Size = new System.Drawing.Size(218, 24);
            this.data_urodzenia_label.TabIndex = 10;
            this.data_urodzenia_label.Text = "data urodzenia";
            this.data_urodzenia_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // miejsce_urodzenia_label
            // 
            this.miejsce_urodzenia_label.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.miejsce_urodzenia_label.Location = new System.Drawing.Point(183, 222);
            this.miejsce_urodzenia_label.Name = "miejsce_urodzenia_label";
            this.miejsce_urodzenia_label.Size = new System.Drawing.Size(218, 24);
            this.miejsce_urodzenia_label.TabIndex = 12;
            this.miejsce_urodzenia_label.Text = "miejsce urodzenia";
            this.miejsce_urodzenia_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // kod_mask
            // 
            this.kod_mask.Location = new System.Drawing.Point(211, 365);
            this.kod_mask.Mask = "00-999";
            this.kod_mask.Name = "kod_mask";
            this.kod_mask.Size = new System.Drawing.Size(160, 20);
            this.kod_mask.TabIndex = 13;
            // 
            // adres
            // 
            this.adres.Location = new System.Drawing.Point(211, 305);
            this.adres.Name = "adres";
            this.adres.Size = new System.Drawing.Size(160, 20);
            this.adres.TabIndex = 14;
            this.adres.Text = "wypełnij pole";
            this.adres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // adres_label
            // 
            this.adres_label.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.adres_label.Location = new System.Drawing.Point(183, 278);
            this.adres_label.Name = "adres_label";
            this.adres_label.Size = new System.Drawing.Size(218, 24);
            this.adres_label.TabIndex = 15;
            this.adres_label.Text = "adres";
            this.adres_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // kod_pocztowy_label
            // 
            this.kod_pocztowy_label.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kod_pocztowy_label.Location = new System.Drawing.Point(183, 340);
            this.kod_pocztowy_label.Name = "kod_pocztowy_label";
            this.kod_pocztowy_label.Size = new System.Drawing.Size(218, 22);
            this.kod_pocztowy_label.TabIndex = 16;
            this.kod_pocztowy_label.Text = "kod pocztowy";
            this.kod_pocztowy_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.kod_pocztowy_label.Click += new System.EventHandler(this.label3_Click);
            // 
            // numer_telefonu_mask
            // 
            this.numer_telefonu_mask.Location = new System.Drawing.Point(211, 526);
            this.numer_telefonu_mask.Mask = "000-000-999";
            this.numer_telefonu_mask.Name = "numer_telefonu_mask";
            this.numer_telefonu_mask.Size = new System.Drawing.Size(160, 20);
            this.numer_telefonu_mask.TabIndex = 17;
            this.numer_telefonu_mask.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            // 
            // numer_telefonu_label
            // 
            this.numer_telefonu_label.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numer_telefonu_label.Location = new System.Drawing.Point(183, 482);
            this.numer_telefonu_label.Name = "numer_telefonu_label";
            this.numer_telefonu_label.Size = new System.Drawing.Size(218, 22);
            this.numer_telefonu_label.TabIndex = 18;
            this.numer_telefonu_label.Text = "numer telefonu";
            this.numer_telefonu_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.numer_telefonu_label.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(211, 571);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(160, 37);
            this.submit.TabIndex = 19;
            this.submit.Text = "WYŚLIJ";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // results
            // 
            this.results.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.results.Location = new System.Drawing.Point(407, 78);
            this.results.Name = "results";
            this.results.Size = new System.Drawing.Size(184, 284);
            this.results.TabIndex = 21;
            this.results.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // image
            // 
            this.image.Location = new System.Drawing.Point(211, 434);
            this.image.Name = "image";
            this.image.Size = new System.Drawing.Size(160, 20);
            this.image.TabIndex = 22;
            this.image.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // zdjecie_label
            // 
            this.zdjecie_label.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.zdjecie_label.Location = new System.Drawing.Point(183, 399);
            this.zdjecie_label.Name = "zdjecie_label";
            this.zdjecie_label.Size = new System.Drawing.Size(218, 22);
            this.zdjecie_label.TabIndex = 23;
            this.zdjecie_label.Text = "adres zdjęcia";
            this.zdjecie_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // zdjecie
            // 
            this.zdjecie.Location = new System.Drawing.Point(425, 415);
            this.zdjecie.Name = "zdjecie";
            this.zdjecie.Size = new System.Drawing.Size(152, 143);
            this.zdjecie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.zdjecie.TabIndex = 24;
            this.zdjecie.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(626, 648);
            this.Controls.Add(this.zdjecie);
            this.Controls.Add(this.zdjecie_label);
            this.Controls.Add(this.image);
            this.Controls.Add(this.results);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.numer_telefonu_label);
            this.Controls.Add(this.numer_telefonu_mask);
            this.Controls.Add(this.kod_pocztowy_label);
            this.Controls.Add(this.adres_label);
            this.Controls.Add(this.adres);
            this.Controls.Add(this.kod_mask);
            this.Controls.Add(this.miejsce_urodzenia_label);
            this.Controls.Add(this.data_urodzenia_label);
            this.Controls.Add(this.imie_label);
            this.Controls.Add(this.nazwisko_label);
            this.Controls.Add(this.miejsce_urodzenia);
            this.Controls.Add(this.data_urodzenia);
            this.Controls.Add(this.imie);
            this.Controls.Add(this.nazwisko);
            this.Controls.Add(this.rejestracja_label);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.zdjecie)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label rejestracja_label;
        private System.Windows.Forms.TextBox nazwisko;
        private System.Windows.Forms.TextBox imie;
        private System.Windows.Forms.DateTimePicker data_urodzenia;
        private System.Windows.Forms.TextBox miejsce_urodzenia;
        private System.Windows.Forms.Label nazwisko_label;
        private System.Windows.Forms.Label imie_label;
        private System.Windows.Forms.Label data_urodzenia_label;
        private System.Windows.Forms.Label miejsce_urodzenia_label;
        private System.Windows.Forms.MaskedTextBox kod_mask;
        private System.Windows.Forms.TextBox adres;
        private System.Windows.Forms.Label adres_label;
        private System.Windows.Forms.Label kod_pocztowy_label;
        private System.Windows.Forms.MaskedTextBox numer_telefonu_mask;
        private System.Windows.Forms.Label numer_telefonu_label;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Label results;
        private System.Windows.Forms.TextBox image;
        private System.Windows.Forms.Label zdjecie_label;
        private System.Windows.Forms.PictureBox zdjecie;
    }
}

