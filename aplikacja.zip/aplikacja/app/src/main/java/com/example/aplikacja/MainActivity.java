package com.example.aplikacja;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);
        EditText password2 = findViewById(R.id.password_repeated);
        Button button =  findViewById(R.id.button);
        TextView results =  findViewById(R.id.results);
        button.setOnClickListener(view -> {
            if (!email.getText().toString().contains("@")) {
                results.setText("Nieprawidłowy adres email");
            } else {
               if (password.getText().toString().equals(password2.getText().toString())) {
                   results.setText("Witaj " + email.getText().toString());
               }
               else {
                   results.setText("Hasła się różnią");
               }
           }
        });

    }
}